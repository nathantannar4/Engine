//
// Copyright (c) Nathan Tannar
//

#import <Foundation/Foundation.h>

//! Project version number for EngineCore.
FOUNDATION_EXPORT double EngineCoreVersionNumber;

//! Project version string for EngineCore.
FOUNDATION_EXPORT const unsigned char EngineCoreVersionString[];

